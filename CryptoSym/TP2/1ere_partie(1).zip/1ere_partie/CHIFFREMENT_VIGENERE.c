/*******************************************************************************/
/****                                                                        ***/
/****                    CHIFFREMENT DE VIGENERE                             ***/
/****                                                                        ***/
/*******************************************************************************/

#include "LIBRAIRIES.h"
#include "CHIFFREMENT_VIGENERE.h"
#include "FONCTIONS_COMMUNES.h"


/******************** Fonction de Chiffrement Vigenere **********************/
void Chiffrement_vigenere(int * cle, int longueur_cle,  int * texte_clair, int * texte_chiffre, int longueur_texte)
{
/*
 * cle contient la clé
 * longueur_cle => la longueur de la clé
 * texte_clair contient le message en clair
 * texte_chiffre va contenir le message une fois chiffré
 * longueur_texte => la longueur du texte
*/

}


/******************** Fonction de Déchiffrement Vigenere **********************/
void Dechiffrement_vigenere( int * cle, int longueur_cle,  int * texte_chiffre, int * texte_dechiffre, int longueur_texte)
{
/*
 * cle contient la clé
 * longueur_cle => la longueur de la clé
 * texte_chiffre contient le message chiffré
 * texte_dechiffre va contenir le message une fois déchiffré
 * longueur_texte => la longueur du texte
*/
}
