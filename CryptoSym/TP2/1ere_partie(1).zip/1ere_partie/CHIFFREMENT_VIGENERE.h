
void Chiffrement_vigenere(int * cle, int longueur_cle,  int * texte_clair, int * texte_chiffre, int longueur_texte);
void Dechiffrement_vigenere( int * cle, int longueur_cle,  int * texte_chiffre, int * texte_clair_2, int longueur_texte);