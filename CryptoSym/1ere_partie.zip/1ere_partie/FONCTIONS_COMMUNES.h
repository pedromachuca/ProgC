
 
void Determination_long_texte(int * LT, char * nom_fichier);
void Lire_et_charger_texte( int *, int , char *);
void Ecrire_chiffre(int * texte_chiffre, int longueur_texte, char * nom_fichier);
void Lire_cle( int cle[26], char *fichier_clef);