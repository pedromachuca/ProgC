#include "LIBRAIRIES.h"
#include "FONCTIONS_COMMUNES.h"


/***********            Fonction pour déterminer la taille du texte donné en entrée             ************/
void Determination_long_texte(int * LT, char * nom_fichier) /*LT est un pointeur qui contiendra la taille du texte*/
{
  /*
   * 
   * 
   * 
   * 
   * 
   * 
   * 
   * 
   * A remplir
   *  
   * 
   * 
   * 
   * 
   * 
   * 
   * 
   */
}

/***********            Fonction de Lecture/chargement du texte                ************/
/*********** Attention !!! on ne stocke que les valeurs de l'alphabet comprises entre 0 et 25 inclus ************/

void Lire_et_charger_texte(int * texte, int longueur_texte, char * nom_fichier)
{
  /*
   * 
   * 
   * 
   * 
   * 
   * 
   * 
   * 
   * A remplir
   *  
   * 
   * 
   * 
   * 
   * 
   * 
   * 
   */
}


/******************* Ecriture du Texte Chiffré dans le fichier donné en parametre ***************************/
void Ecrire_chiffre(int * texte_chiffre, int longueur_texte, char * nom_fichier)
{
  /*
   * 
   * 
   * 
   * 
   * 
   * 
   * 
   * 
   * A remplir
   *  
   * 
   * 
   * 
   * 
   * 
   * 
   * 
   */
}



/************Fonction pour lire et charger la clé contenue dans le fichier "fichier_cle" ********************/
void Lire_cle(int cle[26], char * fichier_cle)
{
  /*
   * 
   * 
   * 
   * 
   * 
   * 
   * 
   * 
   * A remplir
   *  
   * 
   * 
   * 
   * 
   * 
   * 
   * 
   */
}







