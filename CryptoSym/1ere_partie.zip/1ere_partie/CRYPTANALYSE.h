

int Compter_lettre(int * texte, int longueur_texte, int lettre);
void Comptage_nb_apparition(int * texte, int longueur_texte);
void Comptage_frequence_apparition(int * texte, int longueur_texte);
int Compter_bigramme(int * texte, int longueur_texte, int lettre1, int lettre2);
void Affiche_clair(int * texte, int longueur_texte, char * clef_analysee);
void Affiche_alphabetique(int * texte, int longueur_texte);
void Affiche_clair_chiffre(int * texte, int longueur_texte, int longueur, char * clef_analysee);
void Cryptanalyse(int * texte_chiffre, int longueur_texte, char * clef);

