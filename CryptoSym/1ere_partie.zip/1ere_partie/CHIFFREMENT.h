

void Chiffrer_substitution(int * cle,  int * texte_clair, int * texte_chiffre, int longueur_texte);
void Dechiffrer_substitution(int * cle,  int * texte_chiffre, int * texte_dechiffre, int longueur_texte);